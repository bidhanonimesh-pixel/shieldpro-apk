package com.example

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class ShieldAccessibilityService : AccessibilityService() {

    private val TAG = "ShieldV5"
    private val CH  = "shield_v5"
    private val NID = 1001

    // ──────────────────────────────────────────────────────────────────────────
    // KEYWORD LISTS
    // ──────────────────────────────────────────────────────────────────────────

    /**
     * SITE-SPECIFIC keywords — substring match is safe because these terms do
     * not appear in legitimate content (pornhub will never appear in a biology
     * textbook, "bangla chudachudi" never in normal conversation).
     * NOTE: Removed bare "sex" — too generic (Essex, sexuality, sex education).
     */
    private val adultSiteKeywords = setOf(
        // Major adult sites
        "pornhub", "xnxx", "xvideos", "xhamster", "brazzers", "eporner",
        "spankbang", "youporn", "redtube", "tube8", "javhd",
        "nhentai", "hentai2read", "hanime", "hentaihaven",
        "rule34", "gelbooru", "danbooru", "e621", "paheal",
        "aznude", "celebjihad", "fapello", "faphouse", "leakmafia",
        "onlyfans", "chaturbate", "bongacams", "myfreecams",
        "camsoda", "jerkmate", "flirt4free", "livejasmin",
        "adultfriendfinder", "ashleymadison", "sexchat",
        "redgifs", "erothots", "thothub", "simpcity",
        "motherless", "thotsbay", "nudostar",
        "xxxvideo", "xxxtube", "xxxmovie", "freeporn", "hotporn",
        // Multi-word phrases (no false-positive risk)
        "porn video", "sex video", "xxx video", "nude video",
        "naked video", "adult video",
        "bangla sex", "bangla chuda", "bangla chudachudi",
        "bd sex", "bd porn", "desi porn", "indian sex video",
        "chudai video",
        // Bengali Unicode
        "চোদাচুদি", "বাংলা সেক্স", "রেন্ডি", "মাগি", "চুদাচুদি"
    )

    // ── Video app packages — "skip" alone valid here ──────────────────────────
    private val videoApps = setOf(
        "com.google.android.youtube", "com.vanced.android.youtube",
        "app.revanced.android.youtube", "tv.twitch.android.app",
        "com.hotstar.android", "com.netflix.mediaclient",
        "com.amazon.avod.thirdpartyclient",
        "com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro",
        "org.videolan.vlc", "com.facebook.katana"
    )

    // ── Browser packages ──────────────────────────────────────────────────────
    private val browsers = setOf(
        "com.android.chrome", "org.mozilla.firefox",
        "com.opera.browser", "com.opera.mini.native",
        "com.sec.android.app.sbrowser", "com.microsoft.emmx",
        "com.brave.browser", "com.UCMobile.intl", "com.uc.browser.en",
        "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.yandex.browser"
    )

    // ── Reels / TikTok detection ──────────────────────────────────────────────
    // Whole-app block packages
    private val tiktokPkgs = setOf(
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.tiktok.android", "com.ss.android.ugc.aweme"
    )
    // ViewID-based detection for YouTube/IG/FB
    private val reelsViewIds = setOf(
        "com.google.android.youtube:id/reel_watch_fragment_root",
        "com.google.android.youtube:id/shorts_container",
        "com.google.android.youtube:id/reel_recycler",
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/reels_viewer_fragment_container",
        "com.facebook.katana:id/video_container",
        "com.facebook.lite:id/story_container"
    )

    // ── Skip ad view IDs (highest confidence, cross-app) ─────────────────────
    private val skipViewIdSuffixes = listOf(
        "skip_ad_button", "skip_button", "ad_skip_button",
        "skip_ad", "close_ad", "close_ad_button", "skip_ads",
        "ad_close_button", "dismiss_ad", "skip_interstitial"
    )

    // ── Skip text phrases — CONTEXT-AWARE (see trySkipAd) ────────────────────
    private val skipPhrasesGeneral = listOf(
        "skip ad", "skip ads", "skip advertisement",
        "close ad", "close ads", "dismiss ad", "remove ad",
        "no thanks", "not interested", "skip video"
    )
    // In video apps, bare "skip" is almost always the skip-ad button
    private val skipPhrasesVideo = listOf("skip", "skip ad", "skip ads", "skip video")

    // ──────────────────────────────────────────────────────────────────────────
    // STATE
    // ──────────────────────────────────────────────────────────────────────────

    // Global cooldown: prevents home→detect→home loop
    @Volatile private var globalCoolUntil = 0L
    private val GLOBAL_CD = 3_500L

    // Per-package throttle (ms) — main battery-saving mechanism
    private val pkgLastScan = HashMap<String, Long>()
    private val THROTTLE_NORMAL = 900L
    private val THROTTLE_VIDEO  = 350L   // faster for video ad detection

    // Track last blocked package to prevent re-trigger
    @Volatile private var lastBlockedPkg = ""
    @Volatile private var lastBlockedAt  = 0L

    // App screen-time tracking
    @Volatile private var fgPkg   = ""
    @Volatile private var fgStart = 0L

    private lateinit var prefs: SharedPreferences
    private val uiHandler = Handler(Looper.getMainLooper())

    // ──────────────────────────────────────────────────────────────────────────
    // LIFECYCLE
    // ──────────────────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences(ShieldConstants.PREF_NAME, MODE_PRIVATE)
        dailyReset()
        startForeground()
        Log.i(TAG, "ShieldPro v5 connected")
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        flushUsage()
    }

    // ──────────────────────────────────────────────────────────────────────────
    // MAIN EVENT HANDLER
    // ──────────────────────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            if (event == null) return
            val pkg = event.packageName?.toString() ?: return

            // ── 1. System / self filter ────────────────────────────────────
            if (isSystemPkg(pkg)) return

            // ── 2. Whitelist ───────────────────────────────────────────────
            val wl = prefs.getStringSet(ShieldConstants.KEY_WHITELIST, emptySet()) ?: emptySet()
            if (pkg in wl) return

            val now = System.currentTimeMillis()

            // ── 3. Global cooldown (loop prevention) ───────────────────────
            if (now < globalCoolUntil) return

            // ── 4. Per-package throttle (battery saving) ───────────────────
            val throttle = if (pkg in videoApps) THROTTLE_VIDEO else THROTTLE_NORMAL
            if (now - (pkgLastScan[pkg] ?: 0L) < throttle) return
            pkgLastScan[pkg] = now

            // ── 5. Track foreground app for screen-time ────────────────────
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                handleFgChange(pkg)
            }

            // ── 6. Schedule lock ───────────────────────────────────────────
            if (isScheduleLocked()) { doBlock(pkg, "schedule"); return }

            // ── 7. App timer ───────────────────────────────────────────────
            if (timerExceeded(pkg)) { doBlock(pkg, "timer"); return }

            // ── 8. Reels / TikTok block ────────────────────────────────────
            if (prefs.getBoolean(ShieldConstants.KEY_REELS_BLOCK, false)) {
                if (pkg in tiktokPkgs) { doBlock(pkg, "reels"); return }
                if (isReelsVisible(pkg)) { doBlock(pkg, "reels"); return }
            }

            // ── 9. Fast adult detection from event text (no node scan) ─────
            val evText = combineEventText(event)
            if (evText.isNotEmpty() && isAdultText(evText)) {
                doBlock(pkg, "adult"); return
            }

            // ── 10. Node tree scan (only when above checks pass) ───────────
            doNodeScan(pkg)

        } catch (t: Throwable) {
            Log.e(TAG, "Event error", t)
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // NODE TREE SCAN
    // Root acquired ONCE, released in finally — fixes the double-recycle bug
    // ──────────────────────────────────────────────────────────────────────────

    private fun doNodeScan(pkg: String) {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return
        try {
            // Browser URL check
            if (pkg in browsers) {
                val url = extractBrowserUrl(root, pkg)
                if (url != null && isAdultText(url)) { doBlock(pkg, "adult_url"); return }
            }

            // Ad-skip scan
            if (trySkipAd(root, pkg)) return

            // Custom auto-press targets
            tryAutoPress(root, pkg)

        } catch (e: Exception) {
            Log.e(TAG, "Node scan error [$pkg]", e)
        } finally {
            root.recycle()   // ← EXACTLY ONCE, always here
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // AD SKIP — multi-strategy, context-aware
    // ──────────────────────────────────────────────────────────────────────────

    private fun trySkipAd(root: AccessibilityNodeInfo, pkg: String): Boolean {
        // Strategy 1 ── ViewId (most reliable, app-specific buttons)
        for (suffix in skipViewIdSuffixes) {
            val id = "$pkg:id/$suffix"
            val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(id) }
            for (node in nodes) {
                try {
                    if (node.isVisibleToUser && clickUp(node)) {
                        recordSkip(pkg); return true
                    }
                } finally { node.recycle() }
            }
        }

        // Strategy 2 ── Text/description match (context-aware)
        val phrases = if (pkg in videoApps) skipPhrasesVideo else skipPhrasesGeneral
        for (phrase in phrases) {
            val nodes = safeFind { root.findAccessibilityNodeInfosByText(phrase) }
            for (node in nodes) {
                try {
                    if (!node.isVisibleToUser) continue
                    val label = (node.text ?: node.contentDescription)?.toString()?.lowercase()?.trim() ?: continue
                    val vid = node.viewIdResourceName?.lowercase() ?: ""

                    // Bare "skip" safety: only click if it looks like a button,
                    // not inside a comment feed or scroll list
                    if (phrase == "skip" && label == "skip") {
                        if (!isLikelyButton(node)) continue
                        if (isInsideScrollingList(node)) continue
                    }

                    // Confirm label actually matches our phrase
                    if (!isValidSkipLabel(label, phrase, pkg)) continue

                    if (clickUp(node)) { recordSkip(pkg); return true }
                } finally { node.recycle() }
            }
        }
        return false
    }

    /**
     * Accept label if:
     *   • For video apps: label == "skip" OR starts with "skip"
     *   • Otherwise: label must contain the full phrase
     */
    private fun isValidSkipLabel(label: String, phrase: String, pkg: String): Boolean {
        if (pkg in videoApps && phrase == "skip") return label == "skip" || label.startsWith("skip")
        return label.contains(phrase)
    }

    /** Node is a button/clickable or has a clickable parent */
    private fun isLikelyButton(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return true
        val cls = node.className?.toString() ?: ""
        if (cls.contains("Button")) return true
        val p = try { node.parent } catch (e: Exception) { null } ?: return false
        val ok = p.isClickable
        p.recycle()
        return ok
    }

    /** Returns true if node is nested in a RecyclerView / ListView (comment feed) */
    private fun isInsideScrollingList(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = try { node.parent } catch (e: Exception) { null }
        var depth = 0
        while (cur != null && depth < 6) {
            val cls = cur.className?.toString() ?: ""
            if (cls.contains("RecyclerView") || cls.contains("ListView")) {
                cur.recycle(); return true
            }
            val next = try { cur.parent } catch (e: Exception) { null }
            cur.recycle(); cur = next; depth++
        }
        return false
    }

    /** Click node or walk up ≤3 parents for a clickable — proper recycle each step */
    private fun clickUp(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        var cur: AccessibilityNodeInfo? = try { node.parent } catch (e: Exception) { null }
        var d = 0
        while (cur != null && d < 3) {
            if (cur.isClickable) {
                val ok = cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur.recycle(); return ok
            }
            val next = try { cur.parent } catch (e: Exception) { null }
            cur.recycle(); cur = next; d++
        }
        return false
    }

    // ──────────────────────────────────────────────────────────────────────────
    // CUSTOM AUTO-PRESS
    // ──────────────────────────────────────────────────────────────────────────

    private fun tryAutoPress(root: AccessibilityNodeInfo, pkg: String) {
        val targets = prefs.getStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, emptySet()) ?: return
        if (targets.isEmpty()) return
        for (t in targets) {
            val nodes = safeFind { root.findAccessibilityNodeInfosByText(t) }
            for (node in nodes) {
                try { if (node.isVisibleToUser) clickUp(node) }
                finally { node.recycle() }
            }
        }
    }

    // ──────────────────────────────────────────────────────────────────────────
    // BROWSER URL EXTRACTION
    // ──────────────────────────────────────────────────────────────────────────

    private fun extractBrowserUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        // Common URL bar resource IDs across major browsers
        val ids = listOf(
            "$pkg:id/url_bar", "$pkg:id/url", "$pkg:id/url_text",
            "$pkg:id/omnibox_text", "$pkg:id/address_bar",
            "$pkg:id/location_bar", "$pkg:id/search_box_text",
            "$pkg:id/mozac_browser_toolbar_url_view",
            "$pkg:id/toolbar_url_text", "$pkg:id/url_edittext",
            "$pkg:id/search_url_text"
        )
        for (id in ids) {
            val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(id) }
            for (node in nodes) {
                val text = node.text?.toString()
                node.recycle()
                // Must look like a URL (contains dot or slash)
                if (!text.isNullOrBlank() && (text.contains('.') || text.contains('/'))) {
                    return text.lowercase()
                }
            }
        }
        return null
    }

    // ──────────────────────────────────────────────────────────────────────────
    // REELS DETECTION (viewId-based — no heavy tree walk)
    // ──────────────────────────────────────────────────────────────────────────

    private fun isReelsVisible(pkg: String): Boolean {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        try {
            for (vid in reelsViewIds) {
                if (!vid.startsWith(pkg)) continue
                val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(vid) }
                val found = nodes.isNotEmpty()
                nodes.forEach { it.recycle() }
                if (found) return true
            }
        } finally { root.recycle() }
        return false
    }

    // ──────────────────────────────────────────────────────────────────────────
    // ADULT TEXT MATCHING — false-positive safe
    // ──────────────────────────────────────────────────────────────────────────

    private fun isAdultText(text: String): Boolean {
        val lower = text.lowercase()
        // Built-in site keywords (all specific enough for substring match)
        for (kw in adultSiteKeywords) {
            if (lower.contains(kw)) return true
        }
        // User-added custom keywords — minimum 4 chars to avoid accidental matches
        val custom = prefs.getStringSet(ShieldConstants.KEY_CUSTOM_ADULT, emptySet()) ?: emptySet()
        for (kw in custom) {
            if (kw.length >= 4 && lower.contains(kw)) return true
        }
        return false
    }

    // ──────────────────────────────────────────────────────────────────────────
    // BLOCK ACTION
    // Prevents home→detect→home loop via globalCoolUntil + same-package guard
    // ──────────────────────────────────────────────────────────────────────────

    private fun doBlock(pkg: String, reason: String) {
        val now = System.currentTimeMillis()

        // Loop prevention: same package blocked again within 5s → ignore
        if (pkg == lastBlockedPkg && now - lastBlockedAt < 5_000L) return

        lastBlockedPkg  = pkg
        lastBlockedAt   = now
        globalCoolUntil = now + GLOBAL_CD  // ignore all events for 3.5s

        // Count stats
        when (reason) {
            "adult", "adult_url" -> inc(ShieldConstants.KEY_ADULT_TODAY, ShieldConstants.KEY_ADULT_TOTAL)
            "reels"              -> inc(ShieldConstants.KEY_REELS_TODAY,  ShieldConstants.KEY_REELS_TOTAL)
        }

        performGlobalAction(GLOBAL_ACTION_HOME)

        val msg = when (reason) {
            "schedule"    -> "🌙 Night Lock Active!"
            "timer"       -> "⏱️ Time Limit Reached!"
            "reels"       -> "📵 Reels/Shorts Blocked!"
            "adult_url"   -> "🛡️ Harmful URL Blocked!"
            else          -> "🛡️ Adult Content Blocked!"
        }
        uiHandler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun recordSkip(pkg: String) {
        inc(ShieldConstants.KEY_ADS_TODAY, ShieldConstants.KEY_ADS_TOTAL)
        Log.d(TAG, "Ad skipped [$pkg]")
    }

    // ──────────────────────────────────────────────────────────────────────────
    // SCHEDULE LOCK
    // ──────────────────────────────────────────────────────────────────────────

    private fun isScheduleLocked(): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_SCHEDULE_ON, false)) return false
        val c    = Calendar.getInstance()
        val nowM = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val sM   = prefs.getInt(ShieldConstants.KEY_SCHED_START_H, 22) * 60 + prefs.getInt(ShieldConstants.KEY_SCHED_START_M, 0)
        val eM   = prefs.getInt(ShieldConstants.KEY_SCHED_END_H,   6)  * 60 + prefs.getInt(ShieldConstants.KEY_SCHED_END_M,   0)
        // Handles midnight wrap (e.g. 22:00–06:00 → sM > eM)
        return if (sM > eM) nowM >= sM || nowM <= eM else nowM in sM..eM
    }

    // ──────────────────────────────────────────────────────────────────────────
    // APP SCREEN-TIME TIMER
    // ──────────────────────────────────────────────────────────────────────────

    private fun handleFgChange(pkg: String) {
        if (pkg == fgPkg) return
        flushUsage()
        fgPkg   = pkg
        fgStart = System.currentTimeMillis()
    }

    private fun flushUsage() {
        val key = usageKey(fgPkg) ?: run { fgStart = 0L; return }
        if (fgStart == 0L) return
        val ms = System.currentTimeMillis() - fgStart
        prefs.edit().putLong(key, prefs.getLong(key, 0) + ms).apply()
        fgStart = 0L
    }

    private fun usageKey(pkg: String) = when {
        pkg.contains("youtube")   -> ShieldConstants.KEY_USE_YT_TODAY
        pkg in tiktokPkgs || pkg.contains("tiktok") -> ShieldConstants.KEY_USE_TT_TODAY
        pkg.contains("instagram") -> ShieldConstants.KEY_USE_IG_TODAY
        pkg.contains("facebook")  -> ShieldConstants.KEY_USE_FB_TODAY
        else -> null
    }

    private fun timerExceeded(pkg: String): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_APP_TIMER_ON, false)) return false
        val (lk, uk) = when {
            pkg.contains("youtube")   -> ShieldConstants.KEY_TIMER_YT_MINS to ShieldConstants.KEY_USE_YT_TODAY
            pkg in tiktokPkgs || pkg.contains("tiktok") -> ShieldConstants.KEY_TIMER_TT_MINS to ShieldConstants.KEY_USE_TT_TODAY
            pkg.contains("instagram") -> ShieldConstants.KEY_TIMER_IG_MINS to ShieldConstants.KEY_USE_IG_TODAY
            pkg.contains("facebook")  -> ShieldConstants.KEY_TIMER_FB_MINS to ShieldConstants.KEY_USE_FB_TODAY
            else -> return false
        }
        val limitMs = prefs.getInt(lk, 0) * 60_000L
        return limitMs > 0 && prefs.getLong(uk, 0) >= limitMs
    }

    // ──────────────────────────────────────────────────────────────────────────
    // HELPERS
    // ──────────────────────────────────────────────────────────────────────────

    private fun isSystemPkg(pkg: String) =
        pkg == "android" || pkg == packageName ||
        pkg.contains("systemui") || pkg.contains("launcher") ||
        pkg.contains("nexuslauncher") || pkg.contains("quickstep") ||
        pkg.contains("setupwizard")

    private fun combineEventText(e: AccessibilityEvent): String {
        val t = e.text?.joinToString(" ")?.lowercase() ?: ""
        val d = e.contentDescription?.toString()?.lowercase() ?: ""
        return "$t $d".trim()
    }

    private fun inc(todayKey: String, totalKey: String) {
        prefs.edit()
            .putInt(todayKey, prefs.getInt(todayKey, 0) + 1)
            .putInt(totalKey, prefs.getInt(totalKey, 0) + 1)
            .apply()
    }

    /** Wraps findAccessibilityNodeInfosBy* calls to avoid crashing on recycled nodes */
    private fun safeFind(block: () -> List<AccessibilityNodeInfo>?): List<AccessibilityNodeInfo> =
        try { block() ?: emptyList() } catch (e: Exception) { emptyList() }

    private fun dailyReset() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (prefs.getString(ShieldConstants.KEY_LAST_RESET, "") == today) return
        prefs.edit()
            .putString(ShieldConstants.KEY_LAST_RESET, today)
            .putInt(ShieldConstants.KEY_ADS_TODAY,   0)
            .putInt(ShieldConstants.KEY_ADULT_TODAY,  0)
            .putInt(ShieldConstants.KEY_REELS_TODAY,  0)
            .putLong(ShieldConstants.KEY_USE_YT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_TT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_IG_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_FB_TODAY, 0)
            .apply()
    }

    // ── Minimal foreground notification (required by Android for foreground service)
    private fun startForeground() {
        val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        mgr.createNotificationChannel(
            NotificationChannel(CH, "ShieldPro Service", NotificationManager.IMPORTANCE_MIN).apply {
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                enableLights(false)
            }
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("🛡️ ShieldPro Active")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        startForeground(NID, n)
    }
}
