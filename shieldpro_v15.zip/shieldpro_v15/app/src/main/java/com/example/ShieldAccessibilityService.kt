package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

class ShieldAccessibilityService : AccessibilityService() {

    private val TAG = "ShieldV6"
    private val CH  = "shield_v6"
    private val NID = 1001

    // ── Adult site keywords ───────────────────────────────────────────────────
    private val adultSiteKeywords = setOf(
        "pornhub", "xnxx", "xvideos", "xhamster", "brazzers", "eporner",
        "spankbang", "youporn", "redtube", "tube8", "javhd",
        "nhentai", "hentai2read", "hanime", "hentaihaven",
        "rule34", "gelbooru", "danbooru", "e621", "paheal",
        "aznude", "celebjihad", "fapello", "faphouse", "leakmafia",
        "onlyfans", "chaturbate", "bongacams", "myfreecams",
        "camsoda", "jerkmate", "flirt4free", "livejasmin",
        "adultfriendfinder", "ashleymadison", "sexchat",
        "redgifs", "erothots", "thothub", "simpcity",
        "motherless", "thotsbay", "nudostar",
        "xxxvideo", "xxxtube", "xxxmovie", "freeporn", "hotporn",
        "porn video", "sex video", "xxx video", "nude video",
        "naked video", "adult video",
        "bangla sex", "bangla chuda", "bangla chudachudi",
        "bd sex", "bd porn", "desi porn", "indian sex video",
        "chudai video",
        "চোদাচুদি", "বাংলা সেক্স", "রেন্ডি", "মাগি", "চুদাচুদি"
    )

    // ── Video apps ────────────────────────────────────────────────────────────
    private val videoApps = setOf(
        "com.google.android.youtube", "com.vanced.android.youtube",
        "app.revanced.android.youtube", "tv.twitch.android.app",
        "com.hotstar.android", "com.netflix.mediaclient",
        "com.amazon.avod.thirdpartyclient",
        "com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro",
        "org.videolan.vlc", "com.facebook.katana"
    )

    // ── Browser packages ──────────────────────────────────────────────────────
    private val browsers = setOf(
        "com.android.chrome", "org.mozilla.firefox",
        "com.opera.browser", "com.opera.mini.native",
        "com.sec.android.app.sbrowser", "com.microsoft.emmx",
        "com.brave.browser", "com.UCMobile.intl", "com.uc.browser.en",
        "com.duckduckgo.mobile.android", "com.kiwibrowser.browser",
        "com.vivaldi.browser", "com.yandex.browser"
    )

    // ── TikTok packages ───────────────────────────────────────────────────────
    private val tiktokPkgs = setOf(
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.tiktok.android", "com.ss.android.ugc.aweme"
    )

    // ── Reels view IDs ────────────────────────────────────────────────────────
    private val reelsViewIds = setOf(
        "com.google.android.youtube:id/reel_watch_fragment_root",
        "com.google.android.youtube:id/shorts_container",
        "com.google.android.youtube:id/reel_recycler",
        "com.instagram.android:id/clips_viewer_view_pager",
        "com.instagram.android:id/reels_viewer_fragment_container",
        "com.facebook.katana:id/video_container",
        "com.facebook.lite:id/story_container"
    )

    // ── Skip ad view ID suffixes ──────────────────────────────────────────────
    private val skipViewIdSuffixes = listOf(
        "skip_ad_button", "skip_button", "ad_skip_button",
        "skip_ad", "close_ad", "close_ad_button", "skip_ads",
        "ad_close_button", "dismiss_ad", "skip_interstitial"
    )

    // ── Skip phrases ──────────────────────────────────────────────────────────
    private val skipPhrasesGeneral = listOf(
        "skip ad", "skip ads", "skip advertisement",
        "close ad", "close ads", "dismiss ad", "remove ad",
        "no thanks", "not interested", "skip video"
    )
    private val skipPhrasesVideo = listOf("skip", "skip ad", "skip ads", "skip video")

    // ── Browser URL bar IDs (comprehensive list) ──────────────────────────────
    private val urlBarIdSuffixes = listOf(
        "url_bar", "url", "url_text", "omnibox_text", "address_bar",
        "location_bar", "search_box_text", "mozac_browser_toolbar_url_view",
        "toolbar_url_text", "url_edittext", "search_url_text",
        "url_field", "addressbar", "addressBar", "location_bar_edit_text",
        "browser_toolbar_url", "url_bar_title", "search_edit_text"
    )

    // ── STATE ─────────────────────────────────────────────────────────────────
    @Volatile private var globalCoolUntil = 0L
    private val GLOBAL_CD = 3_500L

    private val pkgLastScan    = HashMap<String, Long>()
    private val pkgLastPress   = HashMap<String, Long>() // auto-press এর আলাদা throttle
    private val THROTTLE_NORMAL = 400L
    private val THROTTLE_VIDEO  = 250L
    private val THROTTLE_PRESS  = 800L  // একই button বারবার click না করতে

    @Volatile private var lastBlockedPkg = ""
    @Volatile private var lastBlockedAt  = 0L

    @Volatile private var fgPkg   = ""
    @Volatile private var fgStart = 0L

    private lateinit var prefs: SharedPreferences
    private val uiHandler = Handler(Looper.getMainLooper())

    // ── LIFECYCLE ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences(ShieldConstants.PREF_NAME, MODE_PRIVATE)
        dailyReset()
        startForeground()
        // FIX 3: Service connected হলে dynamic flags set করো
        val info = AccessibilityServiceInfo()
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                          AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                          AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED or
                          AccessibilityEvent.TYPE_VIEW_SCROLLED or
                          AccessibilityEvent.TYPE_VIEW_FOCUSED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                     AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                     AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        info.notificationTimeout = 50
        serviceInfo = info
        Log.i(TAG, "ShieldPro v6 connected")
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        super.onDestroy()
        flushUsage()
    }

    // FIX 3: Security app kill করলেও restart হবে
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Broadcast পাঠাও restart এর জন্য
        val restartIntent = Intent(applicationContext, ShieldRestartReceiver::class.java)
        restartIntent.setPackage(packageName)
        sendBroadcast(restartIntent)
    }

    // ── MAIN EVENT ────────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            if (event == null) return
            val pkg = event.packageName?.toString() ?: return

            if (isSystemPkg(pkg)) return

            val wl = prefs.getStringSet(ShieldConstants.KEY_WHITELIST, emptySet()) ?: emptySet()
            if (pkg in wl) return

            val now = System.currentTimeMillis()

            // ── Auto-press: EVERY event এ চলে, আলাদা throttle ───────────────
            // Facebook/Instagram এ content change হলেই নতুন button আসে
            val hasTargets = !(prefs.getStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, emptySet()) ?: emptySet()).isEmpty()
            if (hasTargets) {
                val lastPress = pkgLastPress[pkg] ?: 0L
                if (now - lastPress >= THROTTLE_PRESS) {
                    val pressRoot = try { rootInActiveWindow } catch (e: Exception) { null }
                    if (pressRoot != null) {
                        try {
                            if (tryAutoPress(pressRoot, pkg)) {
                                pkgLastPress[pkg] = now
                            }
                        } finally {
                            pressRoot.recycle()
                        }
                    }
                }
            }

            // ── বাকি সব check: normal throttle ───────────────────────────────
            if (now < globalCoolUntil) return

            val throttle = if (pkg in videoApps) THROTTLE_VIDEO else THROTTLE_NORMAL
            if (now - (pkgLastScan[pkg] ?: 0L) < throttle) return
            pkgLastScan[pkg] = now

            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                handleFgChange(pkg)
            }

            if (isScheduleLocked()) { doBlock(pkg, "schedule"); return }
            if (timerExceeded(pkg)) { doBlock(pkg, "timer"); return }

            // Reels block
            if (prefs.getBoolean(ShieldConstants.KEY_REELS_BLOCK, false)) {
                val reelsTT = prefs.getBoolean(ShieldConstants.KEY_REELS_TT, true)
                val reelsYT = prefs.getBoolean(ShieldConstants.KEY_REELS_YT, true)
                val reelsIG = prefs.getBoolean(ShieldConstants.KEY_REELS_IG, true)
                val reelsFB = prefs.getBoolean(ShieldConstants.KEY_REELS_FB, true)
                if (reelsTT && pkg in tiktokPkgs) { doBlock(pkg, "reels"); return }
                if (isReelsVisiblePerApp(pkg, reelsYT, reelsIG, reelsFB)) {
                    doBlock(pkg, "reels"); return
                }
            }

            // Adult block — event text fast check
            if (prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_ON, true)) {
                val shouldBlock = when {
                    pkg in browsers           -> prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_BROWSER, true)
                    pkg.contains("youtube")   -> prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_YT, true)
                    else                      -> prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_OTHER, true)
                }
                if (shouldBlock) {
                    val evText = combineEventText(event)
                    if (evText.isNotEmpty() && isAdultText(evText)) {
                        doBlock(pkg, "adult"); return
                    }
                }
            }

            // Node scan (adult URL + ad skip)
            doNodeScan(pkg)

        } catch (t: Throwable) {
            Log.e(TAG, "Event error", t)
        }
    }

    // ── NODE SCAN ─────────────────────────────────────────────────────────────

    private fun doNodeScan(pkg: String) {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return
        try {
            val adultOn  = prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_ON, true)
            val adSkipOn = prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_ON, true)

            // Browser adult block — URL + full page text scan
            if (adultOn) {
                val blockBrowser = prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_BROWSER, true)
                val blockYT      = prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_YT, true)
                val blockOther   = prefs.getBoolean(ShieldConstants.KEY_ADULT_BLOCK_OTHER, true)

                val shouldBlockThis = when {
                    pkg in browsers           -> blockBrowser
                    pkg.contains("youtube")   -> blockYT
                    else                      -> blockOther
                }

                if (shouldBlockThis) {
                    if (pkg in browsers) {
                        val url = extractBrowserUrl(root, pkg)
                        if (url != null && isAdultText(url)) {
                            doBlock(pkg, "adult_url"); return
                        }
                    }
                    if (scanNodeTreeForAdult(root)) {
                        doBlock(pkg, "adult"); return
                    }
                }
            }

            // Ad skip
            if (adSkipOn) {
                val skipAllowed = when {
                    pkg.contains("youtube")   -> prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_YT, true)
                    pkg.contains("instagram") -> prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_INSTA, true)
                    pkg.contains("facebook")  -> prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_FB, true)
                    pkg in browsers           -> prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_BROWSER, true)
                    else                      -> prefs.getBoolean(ShieldConstants.KEY_AD_SKIP_OTHER, true)
                }
                if (skipAllowed) trySkipAd(root, pkg)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Node scan error [$pkg]", e)
        } finally {
            root.recycle()
        }
    }

    // ── FIX 2: Full node tree adult content scan ──────────────────────────────
    // Screen এ visible text গুলো scan করে adult keyword খোঁজে
    private fun scanNodeTreeForAdult(root: AccessibilityNodeInfo): Boolean {
        return scanNode(root, depth = 0)
    }

    private fun scanNode(node: AccessibilityNodeInfo, depth: Int): Boolean {
        if (depth > 8) return false  // অনেক গভীরে যাবে না
        try {
            // এই node এর text check
            val text = node.text?.toString()?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            if ((text.isNotEmpty() && isAdultText(text)) ||
                (desc.isNotEmpty() && isAdultText(desc))) {
                return true
            }
            // Children check
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (e: Exception) { null } ?: continue
                try {
                    if (child.isVisibleToUser && scanNode(child, depth + 1)) return true
                } finally {
                    child.recycle()
                }
            }
        } catch (e: Exception) { /* ignore */ }
        return false
    }

    // ── AD SKIP ───────────────────────────────────────────────────────────────

    private fun trySkipAd(root: AccessibilityNodeInfo, pkg: String): Boolean {
        // Strategy 1: ViewId
        for (suffix in skipViewIdSuffixes) {
            val id = "$pkg:id/$suffix"
            val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(id) }
            for (node in nodes) {
                try {
                    if (node.isVisibleToUser && clickUp(node)) {
                        recordSkip(pkg); return true
                    }
                } finally { node.recycle() }
            }
        }

        // Strategy 2: Text match
        val phrases = if (pkg in videoApps) skipPhrasesVideo else skipPhrasesGeneral
        for (phrase in phrases) {
            val nodes = safeFind { root.findAccessibilityNodeInfosByText(phrase) }
            for (node in nodes) {
                try {
                    if (!node.isVisibleToUser) continue
                    val label = (node.text ?: node.contentDescription)?.toString()?.lowercase()?.trim() ?: continue
                    if (phrase == "skip" && label == "skip") {
                        if (!isLikelyButton(node)) continue
                        if (isInsideScrollingList(node)) continue
                    }
                    if (!isValidSkipLabel(label, phrase, pkg)) continue
                    if (clickUp(node)) { recordSkip(pkg); return true }
                } finally { node.recycle() }
            }
        }
        return false
    }

    private fun isValidSkipLabel(label: String, phrase: String, pkg: String): Boolean {
        if (pkg in videoApps && phrase == "skip") return label == "skip" || label.startsWith("skip")
        return label.contains(phrase)
    }

    private fun isLikelyButton(node: AccessibilityNodeInfo): Boolean {
        if (node.isClickable) return true
        val cls = node.className?.toString() ?: ""
        if (cls.contains("Button")) return true
        val p = try { node.parent } catch (e: Exception) { null } ?: return false
        val ok = p.isClickable
        p.recycle()
        return ok
    }

    private fun isInsideScrollingList(node: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = try { node.parent } catch (e: Exception) { null }
        var depth = 0
        while (cur != null && depth < 6) {
            val cls = cur.className?.toString() ?: ""
            if (cls.contains("RecyclerView") || cls.contains("ListView")) {
                cur.recycle(); return true
            }
            val next = try { cur.parent } catch (e: Exception) { null }
            cur.recycle(); cur = next; depth++
        }
        return false
    }

    // ── CUSTOM AUTO-PRESS — WebView + RecyclerView + সব জায়গায় কাজ করে ────────
    // সমস্যা ছিল:
    // 1. Facebook/Instagram button গুলো WebView এর ভেতরে — findByText কাজ করে না
    // 2. RecyclerView এর ভেতরের button skip করা হচ্ছিল
    // 3. Throttle এর কারণে নতুন button miss হচ্ছিল
    // Fix: সরাসরি পুরো tree walk, RecyclerView skip নেই, প্রতিটা node check
    private fun tryAutoPress(root: AccessibilityNodeInfo, pkg: String): Boolean {
        val targets = prefs.getStringSet(ShieldConstants.KEY_CUSTOM_AUTOPRESS, emptySet()) ?: return false
        if (targets.isEmpty()) return false

        var anyClicked = false
        for (target in targets) {
            val targetLower = target.trim().lowercase()
            if (targetLower.isEmpty()) continue

            // Strategy 1: findAccessibilityNodeInfosByText — দ্রুত
            val byText = safeFind { root.findAccessibilityNodeInfosByText(target) }
            for (node in byText) {
                try {
                    if (!node.isVisibleToUser) continue
                    val t = (node.text ?: node.contentDescription)?.toString()?.lowercase() ?: ""
                    if (t.contains(targetLower) && clickUp(node)) {
                        Log.d(TAG, "AutoPress [strategy1]: '$target' in $pkg")
                        anyClicked = true
                    }
                } finally { node.recycle() }
            }
            if (anyClicked) continue

            // Strategy 2: Full tree walk — WebView, RecyclerView সব জায়গায়
            if (pressInTree(root, targetLower, pkg)) {
                anyClicked = true
            }
        }
        return anyClicked
    }

    // Node tree তে সব visible node check করে — depth limit বেশি রাখা হয়েছে
    private fun pressInTree(node: AccessibilityNodeInfo, targetLower: String, pkg: String): Boolean {
        return pressInTreeR(node, targetLower, pkg, depth = 0)
    }

    private fun pressInTreeR(
        node: AccessibilityNodeInfo,
        targetLower: String,
        pkg: String,
        depth: Int
    ): Boolean {
        if (depth > 20) return false  // Facebook DOM অনেক deep হয়
        try {
            // এই node এর text/description check
            val text = node.text?.toString()?.lowercase()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase()?.trim() ?: ""

            val matches = text.contains(targetLower) || desc.contains(targetLower)
            if (matches && node.isVisibleToUser) {
                if (clickUp(node)) {
                    Log.d(TAG, "AutoPress [tree d=$depth]: '$targetLower' in $pkg (text='$text')")
                    return true
                }
            }

            // Children — সব child check করো, RecyclerView ও skip করো না
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (e: Exception) { null } ?: continue
                try {
                    if (pressInTreeR(child, targetLower, pkg, depth + 1)) return true
                } finally {
                    child.recycle()
                }
            }
        } catch (e: Exception) { /* WebView node exception — ignore */ }
        return false
    }

    // ── CLICK HELPER — 8 parent পর্যন্ত clickable খোঁজে ─────────────────────
    private fun clickUp(node: AccessibilityNodeInfo): Boolean {
        // নিজে clickable?
        if (node.isClickable) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        // Parent এ যাও
        var cur: AccessibilityNodeInfo? = try { node.parent } catch (e: Exception) { null }
        var d = 0
        while (cur != null && d < 8) {
            if (cur.isClickable) {
                val ok = cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                cur.recycle()
                return ok
            }
            val next = try { cur.parent } catch (e: Exception) { null }
            cur.recycle()
            cur = next
            d++
        }
        return false
    }

    // ── FIX 2: BROWSER URL EXTRACTION — আরো বেশি ID ─────────────────────────
    private fun extractBrowserUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        for (suffix in urlBarIdSuffixes) {
            val id = "$pkg:id/$suffix"
            val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(id) }
            for (node in nodes) {
                val text = node.text?.toString()
                node.recycle()
                if (!text.isNullOrBlank() && (text.contains('.') || text.contains('/'))) {
                    return text.lowercase()
                }
            }
        }
        // Fallback: সব EditText node check করো
        return findUrlInEditTexts(root)
    }

    private fun findUrlInEditTexts(node: AccessibilityNodeInfo): String? {
        try {
            val cls = node.className?.toString() ?: ""
            if (cls.contains("EditText")) {
                val text = node.text?.toString()
                if (!text.isNullOrBlank() && (text.contains('.') || text.contains('/'))) {
                    return text.lowercase()
                }
            }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (e: Exception) { null } ?: continue
                try {
                    val found = findUrlInEditTexts(child)
                    if (found != null) return found
                } finally { child.recycle() }
            }
        } catch (e: Exception) { /* ignore */ }
        return null
    }

    // ── REELS DETECTION ───────────────────────────────────────────────────────
    private fun isReelsVisiblePerApp(pkg: String, yt: Boolean, ig: Boolean, fb: Boolean): Boolean {
        val root = try { rootInActiveWindow } catch (e: Exception) { null } ?: return false
        try {
            for (vid in reelsViewIds) {
                if (!vid.startsWith(pkg)) continue
                val appAllowed = when {
                    pkg.contains("youtube")   -> yt
                    pkg.contains("instagram") -> ig
                    pkg.contains("facebook")  -> fb
                    else -> true
                }
                if (!appAllowed) continue
                val nodes = safeFind { root.findAccessibilityNodeInfosByViewId(vid) }
                val found = nodes.isNotEmpty()
                nodes.forEach { it.recycle() }
                if (found) return true
            }
        } finally { root.recycle() }
        return false
    }

    // ── ADULT TEXT MATCHING ───────────────────────────────────────────────────
    private fun isAdultText(text: String): Boolean {
        val lower = text.lowercase()
        for (kw in adultSiteKeywords) {
            if (lower.contains(kw)) return true
        }
        val custom = prefs.getStringSet(ShieldConstants.KEY_CUSTOM_ADULT, emptySet()) ?: emptySet()
        for (kw in custom) {
            if (kw.length >= 4 && lower.contains(kw.lowercase())) return true
        }
        return false
    }

    // ── BLOCK ACTION ──────────────────────────────────────────────────────────
    private fun doBlock(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockedAt < 5_000L) return

        lastBlockedPkg  = pkg
        lastBlockedAt   = now
        globalCoolUntil = now + GLOBAL_CD

        when (reason) {
            "adult", "adult_url" -> inc(ShieldConstants.KEY_ADULT_TODAY, ShieldConstants.KEY_ADULT_TOTAL)
            "reels"              -> inc(ShieldConstants.KEY_REELS_TODAY,  ShieldConstants.KEY_REELS_TOTAL)
        }

        performGlobalAction(GLOBAL_ACTION_HOME)

        val msg = when (reason) {
            "schedule"    -> "🌙 Night Lock Active!"
            "timer"       -> "⏱️ Time Limit Reached!"
            "reels"       -> "📵 Reels/Shorts Blocked!"
            "adult_url"   -> "🛡️ Harmful URL Blocked!"
            else          -> "🛡️ Adult Content Blocked!"
        }
        uiHandler.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show() }
    }

    private fun recordSkip(pkg: String) {
        inc(ShieldConstants.KEY_ADS_TODAY, ShieldConstants.KEY_ADS_TOTAL)
        Log.d(TAG, "Ad skipped [$pkg]")
    }

    // ── SCHEDULE LOCK ─────────────────────────────────────────────────────────
    private fun isScheduleLocked(): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_SCHEDULE_ON, false)) return false
        val c    = Calendar.getInstance()
        val nowM = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val sM   = prefs.getInt(ShieldConstants.KEY_SCHED_START_H, 22) * 60 + prefs.getInt(ShieldConstants.KEY_SCHED_START_M, 0)
        val eM   = prefs.getInt(ShieldConstants.KEY_SCHED_END_H,   6)  * 60 + prefs.getInt(ShieldConstants.KEY_SCHED_END_M,   0)
        return if (sM > eM) nowM >= sM || nowM <= eM else nowM in sM..eM
    }

    // ── APP SCREEN-TIME ───────────────────────────────────────────────────────
    private fun handleFgChange(pkg: String) {
        if (pkg == fgPkg) return
        flushUsage()
        fgPkg   = pkg
        fgStart = System.currentTimeMillis()
    }

    private fun flushUsage() {
        val key = usageKey(fgPkg) ?: run { fgStart = 0L; return }
        if (fgStart == 0L) return
        val ms = System.currentTimeMillis() - fgStart
        prefs.edit().putLong(key, prefs.getLong(key, 0) + ms).apply()
        fgStart = 0L
    }

    private fun usageKey(pkg: String) = when {
        pkg.contains("youtube")   -> ShieldConstants.KEY_USE_YT_TODAY
        pkg in tiktokPkgs || pkg.contains("tiktok") -> ShieldConstants.KEY_USE_TT_TODAY
        pkg.contains("instagram") -> ShieldConstants.KEY_USE_IG_TODAY
        pkg.contains("facebook")  -> ShieldConstants.KEY_USE_FB_TODAY
        else -> null
    }

    private fun timerExceeded(pkg: String): Boolean {
        if (!prefs.getBoolean(ShieldConstants.KEY_APP_TIMER_ON, false)) return false
        val (lk, uk) = when {
            pkg.contains("youtube")   -> ShieldConstants.KEY_TIMER_YT_MINS to ShieldConstants.KEY_USE_YT_TODAY
            pkg in tiktokPkgs || pkg.contains("tiktok") -> ShieldConstants.KEY_TIMER_TT_MINS to ShieldConstants.KEY_USE_TT_TODAY
            pkg.contains("instagram") -> ShieldConstants.KEY_TIMER_IG_MINS to ShieldConstants.KEY_USE_IG_TODAY
            pkg.contains("facebook")  -> ShieldConstants.KEY_TIMER_FB_MINS to ShieldConstants.KEY_USE_FB_TODAY
            else -> return false
        }
        val limitMs = prefs.getInt(lk, 0) * 60_000L
        return limitMs > 0 && prefs.getLong(uk, 0) >= limitMs
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────
    private fun isSystemPkg(pkg: String) =
        pkg == "android" || pkg == packageName ||
        pkg.contains("systemui") || pkg.contains("launcher") ||
        pkg.contains("nexuslauncher") || pkg.contains("quickstep") ||
        pkg.contains("setupwizard")

    private fun combineEventText(e: AccessibilityEvent): String {
        val t = e.text?.joinToString(" ")?.lowercase() ?: ""
        val d = e.contentDescription?.toString()?.lowercase() ?: ""
        return "$t $d".trim()
    }

    private fun inc(todayKey: String, totalKey: String) {
        prefs.edit()
            .putInt(todayKey, prefs.getInt(todayKey, 0) + 1)
            .putInt(totalKey, prefs.getInt(totalKey, 0) + 1)
            .apply()
    }

    private fun safeFind(block: () -> List<AccessibilityNodeInfo>?): List<AccessibilityNodeInfo> =
        try { block() ?: emptyList() } catch (e: Exception) { emptyList() }

    private fun dailyReset() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (prefs.getString(ShieldConstants.KEY_LAST_RESET, "") == today) return
        prefs.edit()
            .putString(ShieldConstants.KEY_LAST_RESET, today)
            .putInt(ShieldConstants.KEY_ADS_TODAY,   0)
            .putInt(ShieldConstants.KEY_ADULT_TODAY,  0)
            .putInt(ShieldConstants.KEY_REELS_TODAY,  0)
            .putLong(ShieldConstants.KEY_USE_YT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_TT_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_IG_TODAY, 0)
            .putLong(ShieldConstants.KEY_USE_FB_TODAY, 0)
            .apply()
    }

    // ── FOREGROUND NOTIFICATION ───────────────────────────────────────────────
    private fun startForeground() {
        val mgr = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        mgr.createNotificationChannel(
            NotificationChannel(CH, "ShieldPro Service", NotificationManager.IMPORTANCE_MIN).apply {
                lockscreenVisibility = Notification.VISIBILITY_SECRET
                setShowBadge(false)
                setSound(null, null)
                enableVibration(false)
                enableLights(false)
            }
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("🛡️ ShieldPro Active")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        startForeground(NID, n)
    }
}
