# ShieldPro v5 — Complete Bugfix + Feature Release

## ✅ Bugs Fixed

| # | Bug | Fix Applied |
|---|-----|-------------|
| 1 | `rootNode.recycle()` double-call crash | Root acquired once, recycled only in `finally` — never inside loop |
| 2 | Child node leak on exception | Every child node in its own `try/finally` |
| 3 | `"skip"` keyword false-clicks (comments, tutorials) | Context-aware: bare "skip" only clicked in video apps, only if it's a button, not inside RecyclerView/ListView |
| 4 | `notificationTimeout=300ms` — battery drain | Changed to `500ms` in XML + 900ms per-package code throttle |
| 5 | 2s adult-block cooldown causing missed blocks | Replaced with `globalCoolUntil` system (3.5s global pause after any block) |
| 6 | Home→detect→home loop | `lastBlockedPkg` + `globalCoolUntil` breaks the loop |
| 7 | Icon-button ads not detected (no text) | ViewId-based skip detection (10+ known IDs like `skip_ad_button`, `ad_close_button`) |
| 8 | False-positive adult detection (biology, Essex, etc.) | Removed bare "sex"; all keywords are specific phrases or site names |
| 9 | `exported=true` on accessibility service | Required by Android (system binds via `BIND_ACCESSIBILITY_SERVICE` — no third-party risk); comment added |
| 10 | Schedule lock — no real time picker | Native Android `TimePickerDialog` — tap the time card to pick |
| 11 | Notification cluttering status bar | Removed counter notification; only foreground service notification (silent, minimal) |
| 12 | Keyword detection fails on image/icon buttons | ViewId strategy runs first, then text, then description |

---

## ✨ Features

| Feature | Details |
|---------|---------|
| **Stats Screen** | Today bars (Ads / Adult / Reels) + Lifetime totals + App screen time |
| **Custom Block Keywords** | Add/remove your own words (min 4 chars to avoid false positives) |
| **Custom Auto-Press** | Add any button text to auto-click in any app (e.g. "Allow", "Later", "Got it") |
| **App Whitelist** | Exclude packages from all scanning |
| **PIN Lock** | SHA-256 hashed, 4–6 digit PIN; numeric keypad UI |
| **Schedule Lock** | Tap time cards → native Android time picker → midnight-wrap supported |
| **Reels / Shorts Block** | ViewId-based: YouTube Shorts, TikTok (whole app), Instagram Reels, FB Reels |
| **App Screen Time Limit** | YouTube / TikTok / Instagram / Facebook — slider (10–300 min/day) |
| **Real Browser URL Block** | Checks URL bar of Chrome, Firefox, Samsung, Brave, Opera, UC, Kiwi etc. |
| **60+ Adult Keywords** | Bengali romanized, Bengali Unicode, English site names & phrases |
| **Battery Optimized** | 500ms XML timeout + 900ms/350ms code throttle + no heavy flags |
| **Working 3-screen nav** | Home 🔒 → Stats ⭐ → Settings 🔧 |

---

## Setup (First Time)
1. Open app → tap **Accessibility** card → enable ShieldPro
2. Tap **Eco Mode** card → grant battery unrestricted
3. Tap **Uninstall Protection** → activate device admin
4. Tap **DNS Firewall** card → paste `family.adguard-dns.com` in Private DNS

---

## Architecture
```
ShieldConstants.kt          — all SharedPreferences keys
ShieldAccessibilityService  — background engine (bugs fixed, all detection)
MainActivity.kt             — 3-screen UI (Home / Stats / Settings)
ShieldReceivers.kt          — Boot receiver + Device Admin
```

## Build
Open in Android Studio → Sync Gradle → Run
- minSdk 24 (Android 7.0+)
- targetSdk 36
