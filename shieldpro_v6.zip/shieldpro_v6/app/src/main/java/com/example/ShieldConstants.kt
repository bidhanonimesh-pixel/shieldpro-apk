package com.example

object ShieldConstants {
    const val PREF_NAME = "shieldpro_prefs"

    // Daily counters
    const val KEY_ADS_TODAY        = "ads_today"
    const val KEY_ADULT_TODAY      = "adult_today"
    const val KEY_REELS_TODAY      = "reels_today"

    // All-time totals
    const val KEY_ADS_TOTAL        = "ads_total"
    const val KEY_ADULT_TOTAL      = "adult_total"
    const val KEY_REELS_TOTAL      = "reels_total"

    // Date for daily reset
    const val KEY_LAST_RESET       = "last_reset"

    // Custom adult block keywords (Set<String>)
    const val KEY_CUSTOM_ADULT     = "custom_adult"

    // Custom auto-press targets (Set<String>)
    const val KEY_CUSTOM_AUTOPRESS = "custom_autopress"

    // Whitelist packages (Set<String>)
    const val KEY_WHITELIST        = "whitelist"

    // PIN
    const val KEY_PIN_ENABLED      = "pin_enabled"
    const val KEY_PIN_HASH         = "pin_hash"

    // Schedule lock
    const val KEY_SCHEDULE_ON      = "schedule_on"
    const val KEY_SCHED_START_H    = "sched_sh"
    const val KEY_SCHED_START_M    = "sched_sm"
    const val KEY_SCHED_END_H      = "sched_eh"
    const val KEY_SCHED_END_M      = "sched_em"

    // Reels / Shorts block
    const val KEY_REELS_BLOCK      = "reels_block"

    // App timer
    const val KEY_APP_TIMER_ON     = "app_timer_on"
    const val KEY_TIMER_YT_MINS    = "timer_yt"
    const val KEY_TIMER_TT_MINS    = "timer_tt"
    const val KEY_TIMER_IG_MINS    = "timer_ig"
    const val KEY_TIMER_FB_MINS    = "timer_fb"

    // App usage today (ms)
    const val KEY_USE_YT_TODAY     = "use_yt"
    const val KEY_USE_TT_TODAY     = "use_tt"
    const val KEY_USE_IG_TODAY     = "use_ig"
    const val KEY_USE_FB_TODAY     = "use_fb"
}
