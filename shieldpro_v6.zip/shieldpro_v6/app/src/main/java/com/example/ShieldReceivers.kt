package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import android.app.admin.DeviceAdminReceiver

class ShieldBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || 
            intent.action == "android.intent.action.LOCKED_BOOT_COMPLETED" || 
            intent.action == Intent.ACTION_REBOOT) {
            Log.d("ShieldBoot", "Device restarted. Shield is active in the background.")
            // Accessibility service will be automatically restarted by the OS if it was enabled.
        }
    }
}

class ShieldDeviceAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Log.d("ShieldAdmin", "Device Administrator Enabled. App is now protected from uninstallation.")
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return "Warning: Disabling this will remove protection against ads and adult content. Are you sure you want to disable ShieldPro?"
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Log.d("ShieldAdmin", "Device Administrator Disabled.")
    }
}
